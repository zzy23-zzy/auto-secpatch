# 🛡️ Auto-SecPatch Agent
**基于 LangGraph 的自愈式代码安全补丁智能体**

### 🌟 项目简介
本项目是一个能够自动识别并修复 Python 代码安全漏洞的智能体。通过 LangGraph 构建闭环工作流，Agent 能够对输入代码进行静态分析、逻辑重构，并在虚拟环境中执行验证。

### 🛠️ 技术栈
- **推理大脑**: DeepSeek-V3 / Gemini
- **流程编排**: LangGraph (State Machine)
- **前端界面**: Streamlit
- **验证环境**: Python Subprocess

### 📂 核心功能
- **SQL 注入修复**: 自动将拼接字符串查询重构为参数化查询。
- **敏感信息脱敏**: 识别硬编码的 API Key 或密码，并重构为环境变量调用。
- **闭环验证**: 修复后的代码会自动经过执行器测试，确保修复过程不破坏原有逻辑。